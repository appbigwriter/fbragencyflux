Sergio Castro é COO do FBR Group e prefere ser atendido em pt-BR.
§
Estrutura de projetos no diretório F:/Projetos/_FBR-Agency segue FBRAgency/Companies/<empresa>/Projects/<projeto>; projeto inicial: FBRSigns/Projects/Amazon.
§
Para o projeto FBRSigns Amazon: objetivo é venda direta na Amazon; comunicação 100% em inglês; marca FBRSigns; públicos prioritários são trade-show exhibitors, pequenos negócios locais e event planners/agencies; mídia inicial de US$350/mês dividida 50% Amazon PPC, 30% Meta e 20% TikTok; Facebrasil terá 2 artigos indexáveis por semana para aquisição orgânica.