# Referência: estrutura de projetos

## Árvore padrão
```text
FBRAgency/
└── Companies/
    └── <Empresa>/
        └── Projects/
            └── <Projeto>/
```

## Exemplo
```text
FBRAgency/Companies/FBRSigns/Projects/Amazon/
```

## Checklist
- [ ] Empresa identificada e nome preservado literalmente.
- [ ] Projeto identificado e nome preservado literalmente.
- [ ] `Companies/<Empresa>/Projects/<Projeto>` usado sem atalhos.
- [ ] Existência da pasta verificada por listagem/árvore.
- [ ] Arquivos existentes protegidos contra sobrescrita ou movimentação não autorizada.
- [ ] Pendências e próximo especialista registrados.
