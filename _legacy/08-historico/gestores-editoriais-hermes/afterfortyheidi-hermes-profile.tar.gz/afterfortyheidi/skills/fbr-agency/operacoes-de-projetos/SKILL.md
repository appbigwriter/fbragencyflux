---
name: operacoes-de-projetos
description: Use when projects arrive. Organize folders and route work.
version: 1.0.0
metadata:
  hermes:
    tags: [fbr-agency, projetos, intake, estrutura, kanban]
    category: fbr-agency
---
# Operações de Projetos da FBR Agency

## When to Use
Use ao receber uma nova demanda de qualquer empresa do FBR Group, especialmente quando for necessário criar ou localizar a pasta do projeto e preparar o encaminhamento para especialistas.

## Objetivo
Transformar uma demanda em um projeto rastreável, com estrutura de arquivos previsível, briefing filtrado, responsável, dependências e critério de aceite.

## Fluxo de Intake
1. Identificar **empresa** e **projeto** usando os nomes fornecidos pelo solicitante.
2. Extrair objetivo, público, oferta, prazo, orçamento, ativos, formato, prioridade e critério de sucesso.
3. Perguntar apenas o que bloqueia a criação ou execução; registrar lacunas não bloqueadoras como pendências.
4. Classificar a fase e escolher o agente especialista adequado.
5. Criar o card do trabalho com entrada, saída, responsável, prazo, aceite, dependências e aprovação necessária.
6. Delegar tarefas independentes em paralelo; respeitar dependências antes de mover para a próxima fase.
7. Consolidar entrega, riscos, aprovações pendentes e arquivos/links verificáveis.

## Convenção Obrigatória de Pastas
A raiz dos trabalhos é:

```text
FBRAgency/Companies/<Empresa>/Projects/<Projeto>/
```

Para uma demanda da FBRSigns chamada Amazon, o caminho é:

```text
FBRAgency/Companies/FBRSigns/Projects/Amazon/
```

Nomes de empresa e projeto devem ser preservados literalmente. Não criar uma pasta `Projects` diretamente dentro de `FBRAgency` quando a empresa puder ser identificada.

Consulte `references/estrutura-de-projetos.md` para a árvore e o checklist de verificação.

## Critérios de Verificação
- A árvore final corresponde exatamente à hierarquia solicitada.
- A pasta do projeto existe e está pronta para receber os arquivos.
- Nenhum arquivo existente foi movido, sobrescrito ou excluído sem autorização.
- O projeto tem briefing filtrado, responsável, saída esperada e critério de aceite.
- O relatório final inclui caminho verificável, pendências e próximos passos.

## Pitfalls
- Interpretar uma correção de hierarquia como uma nova pasta paralela, em vez de ajustar o caminho anterior.
- Normalizar ou “corrigir” maiúsculas, espaços ou identificadores sem confirmação.
- Delegar briefing cru ou prometer execução antes de validar dependências.
- Declarar projeto concluído apenas porque a pasta foi criada.
