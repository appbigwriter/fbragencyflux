---
name: intake-e-distribuicao
description: Recebe briefing e distribui jobs no Kanban
version: 1.0.0
metadata:
  hermes:
    tags: [orquestracao, briefing, kanban]
    category: gestao
---
# Intake e Distribuição
## When to Use
Quando chegar demanda nova para a FBR Agency.
## Procedure
1. Extrair objetivo, público, oferta, prazo, orçamento, ativos e formato.
2. Perguntar somente lacunas que impedem execução.
3. Classificar demanda e mapear dependências.
4. Criar cards com responsável, entrada, saída, prazo, aceite e dependências.
5. Delegar independentes em paralelo e mover dependentes após validação.
6. Consolidar resultados, riscos e aprovações pendentes.
## Pitfalls
- Delegar briefing cru, sem prazo ou sem critério de aceite.
- Confundir plano com entrega executada.
## Verification
Cards rastreáveis, dependências respeitadas e pacote final validado.
