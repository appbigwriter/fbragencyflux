---
name: fbr-marketing-orquestracao
description: Use when marketing demands arrive. Route and govern jobs.
version: 1.0.0
metadata:
  hermes:
    tags: [fbr-agency, marketing, intake, orquestracao, midia, conteudo]
    category: fbr-agency
---
# Orquestração de Marketing da FBR Agency

## When to Use
Use quando uma empresa do FBR Group trouxer uma demanda de marketing que precise ser filtrada, transformada em jobs e encaminhada a especialistas.

## Princípio de escopo
A Agência deve concentrar o intake em estratégia, posicionamento, copy, conteúdo, SEO, mídia paga, criativos, mensuração e governança de aprovação. Se o cliente informar que temas jurídicos, documentais, fiscais, logísticos ou operacionais estão sendo resolvidos por outras áreas, registre-os como fora de escopo e não os repita como bloqueadores.

## Intake de marketing
1. Extrair objetivo, público, oferta/CTA, marca, idioma, região, canais, orçamento, cadência, assets, regras de claims, KPIs, prazo e aprovador.
2. Separar decisões bloqueadoras de pendências não bloqueadoras. Não exigir preço, documentação ou detalhes operacionais quando o pedido é apenas estratégia de marketing e essas áreas já foram assumidas por terceiros; registrar a dependência sem paralisar o trabalho.
3. Fixar pressupostos explícitos quando houver lacunas: por exemplo, idioma e mercado podem ser definidos pelo cliente, enquanto identidade visual ou distribuição de verba devem ser confirmadas.
4. Conferir documentos-fonte específicos, como gates por produto, contra resumos executivos e calendários. Em caso de divergência, sinalizar o conflito e não declarar publicação liberada sem aprovação.
5. Produzir um briefing filtrado com: objetivo, públicos prioritários, posicionamento, canais, divisão de verba, calendário, entregas, responsáveis, critérios de aceite e aprovações.

## Distribuição por especialidade
- **Rafa:** aquisição, Amazon PPC, Meta/TikTok, públicos, funil, KPIs e otimização.
- **Caio:** copy de conversão, SEO, artigos indexáveis, legendas e adaptações de canal.
- **Lia:** direção visual, layouts, carrosséis, estáticos e sistemas de criativos.
- **Vito:** roteiros, decupagem, vídeos curtos, edição e versões por plataforma.
- **Theo:** páginas, tracking e integrações de marketing quando solicitados.
- **Kora:** Kanban, sprint, capacidade, dependências e relatórios operacionais.
- **Iris:** consolidação, validação de escopo, compliance editorial e encaminhamento para aprovação.

Delegar frentes independentes em paralelo, com contexto completo e saída verificável. Não pedir ao especialista uma peça final quando a dependência estratégica ainda não está aprovada.

## Mídia paga e orgânico
Registrar sempre o orçamento por canal, objetivo da campanha, público, evento de conversão e critério de otimização. Para conteúdo orgânico indexável, definir tema, intenção de busca, público, CTA, ligação com a oferta e reaproveitamento social. Campanhas pagas e conteúdo orgânico devem falar com os mesmos segmentos sem prometer claims não aprovados.

## Copy-mestra e consistência multicanal
Quando o cliente considerar a copy existente genérica ou insuficiente, encaminhar ao copywriter uma reconstrução de **copy-mestra por produto** antes de solicitar novas peças. Cada master deve cobrir posicionamento, público/job-to-be-done, ângulo, promessa permitida, provas, título, bullets, descrição, customização, FAQ, CTA, claims proibidos e mapa dos assets. Criar também um sistema multicanal que determine o que permanece e o que pode ser adaptado em Amazon/A+, Meta, TikTok, SEO, legendas e roteiros. Preservar os arquivos originais; novas versões devem ter nomes e caminhos rastreáveis.

## Compliance e claims
Usar a fonte de claims específica de cada produto. **`claims-control.md` prevalece sobre qualquer fonte secundária**, incluindo especificações de marketplace, copies antigas, imagens ou referências de concorrentes. Se a nova copy inserir detalhe não explicitamente aprovado no controle — dimensão, material, acessório, performance, prazo, entrega ou configuração — remover ou marcar `[NEEDS CONFIRMATION]` antes do aceite. Não importar características de concorrentes para produtos AbS ou aprovados por similaridade. Diferenciar claramente: copy validada, asset aprovado, gate físico e aprovação final de canal. Claims desconhecidos permanecem fora da peça até confirmação.

## Verificação de entregas delegadas
O auto-relato do especialista não é prova suficiente. Após cada handoff, verificar os arquivos no caminho real e conferir cobertura, idioma, quantidade de itens, preservação dos originais, placeholders e claims. Em copy de produto, confirmar todos os produtos solicitados, exatamente cinco bullets quando aplicável e rastreabilidade dos assets. Se a QA detectar conflito, devolver ao especialista para correção antes de apresentar como pronto.

## Governança e aceite
Cada job deve conter entrada, responsável, saída, prazo, dependências, critério de aceite e aprovador. Publicação, alteração comercial e investimento de mídia exigem aprovação explícita do responsável. Relatórios devem separar fatos medidos, decisões, riscos e próximos testes; nunca inventar resultados.

## Pitfalls
- Transformar questões jurídicas ou operacionais já fora do escopo em questionário obrigatório de marketing.
- Fazer perguntas amplas demais antes de extrair o que já está definido no briefing.
- Confundir um calendário ou resumo com a fonte específica de aprovação.
- Iniciar publicação ou gasto de verba sem registrar aprovação.
- Criar conteúdo em idioma, marca ou canal diferente do definido pelo cliente.
- Delegar sem orçamento, público, CTA, critério de aceite ou dependências.

## Verification
Antes de consolidar: escopo de marketing confirmado; público, idioma, marca, canais e orçamento registrados; jobs atribuídos; dependências e conflitos sinalizados; claims rastreáveis; nenhuma publicação ou verba tratada como executada sem prova e aprovação.
